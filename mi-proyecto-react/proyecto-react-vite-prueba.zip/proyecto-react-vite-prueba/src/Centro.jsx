// import React from 'react'
import './App.css'

// Muy importante que vayan la primera letra del componente en MAYUSCULA 
export default function Centro() {
  return (
    <h1>CIFP César Manrique</h1>
  )
}
