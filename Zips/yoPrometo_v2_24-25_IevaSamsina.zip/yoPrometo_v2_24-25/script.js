let contadorDeClicks = 0;
let contadorDeTeclas = 0;

// Listener para contar clics
document.addEventListener("click", () => {
    contadorDeClicks++;
    console.log("CLICK!!");
});

// Listener para contar teclas
document.addEventListener("keydown", () => {
    contadorDeTeclas++;
    console.log("TECLA!!");
});

function prometer4Clicks() {
    return new Promise((resolve, reject) => {
        console.log("1. Iniciar promesa de hacer 4 clicks");
        console.log("2. Dispones de 5 segundos para cumplirla");

        setTimeout(() => {
            if (contadorDeClicks >= 4) {
                resolve("3SI. ¡¡Muy Bien!! ... Has cumplido tu promesa de hacer 4 clicks en 5 segundos");
            } else {
                reject("3NO. ¡¡VAYA!! NO has cumplido tu promesa de hacer 4 clicks en 5 segundos");
            }
        }, 5000);
    });
}

function prometer4Teclas() {
    return new Promise((resolve, reject) => {
        console.log("4. Iniciar promesa de pulsar 4 teclas");
        console.log("5. Dispones de 5 segundos para cumplirla");

        setTimeout(() => {
            if (contadorDeTeclas >= 4) {
                resolve("6SI. ¡¡Muy Bien!! ... Has cumplido tu promesa de pulsar 4 teclas en 5 segundos");
            } else {
                reject("6NO. ¡¡VAYA!! NO has cumplido tu promesa de pulsar 4 teclas en 5 segundos");
            }
        }, 5000);
    });
}

// Ejecución en secuencia usando async/await
async function iniciarPromesasEnSecuencia() {
    try {
        const mensajeClicks = await prometer4Clicks();
        console.log(mensajeClicks);
    } catch (errorClicks) {
        console.log(errorClicks);
    }

    try {
        const mensajeTeclas = await prometer4Teclas();
        console.log(mensajeTeclas);
    } catch (errorTeclas) {
        console.log(errorTeclas);
    }
}

iniciarPromesasEnSecuencia();
