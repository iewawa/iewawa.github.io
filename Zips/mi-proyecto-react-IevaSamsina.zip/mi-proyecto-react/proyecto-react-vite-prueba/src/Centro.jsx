import './App.css'

export default function Centro() {
  return (
    <h1>CIFP César Manrique</h1>
  )
}
