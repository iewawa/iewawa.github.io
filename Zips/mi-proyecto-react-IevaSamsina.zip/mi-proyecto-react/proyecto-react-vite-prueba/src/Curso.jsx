import './App.css'

export default function Curso() {
  return (
    <div>Mi curso de 2º DAW B</div>
  )
}
