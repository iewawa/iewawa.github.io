export const alumnos = [
    {id: 1, grupo:"A", nombre: "Juan"},
    {id: 2, grupo:"A", nombre: "Eva"},
    {id: 3, grupo:"B", nombre: "Ana"},
    {id: 4, grupo:"B", nombre: "Julia"},
    {id: 5, grupo:"B", nombre:"Antonio"}
  ];