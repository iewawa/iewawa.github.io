import './App.css'

export default function Inicio() {
  return (
    <h1>Página de Inicio</h1>
  )
}
